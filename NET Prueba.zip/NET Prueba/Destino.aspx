<%@ Page Language="VB" AutoEventWireup="false" CodeBehind="Destino.aspx.vb" Inherits="EvaluacionNet.Destino" %>
<!DOCTYPE html>
<html lang="es">
<head runat="server">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Empresa seleccionada</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f5f7fa; color: #1d2939; }
        .container { max-width: 680px; margin: 40px auto; padding: 28px; background: white; border: 1px solid #d0d5dd; border-radius: 8px; }
        img { width: 120px; height: 120px; object-fit: contain; }
        a { display: inline-block; margin-top: 18px; color: #195ea8; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <main class="container">
            <h1>Empresa seleccionada</h1>
            <asp:Label ID="lblCanal" runat="server" /><br />
            <asp:Image ID="imgLogo" runat="server" />
            <h2><asp:Literal ID="litNombre" runat="server" /></h2>
            <asp:HyperLink ID="lnkListado" runat="server" Text="Volver al listado" />
        </main>
    </form>
</body>
</html>
