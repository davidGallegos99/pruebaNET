Imports System
Imports System.Collections.Generic
Imports System.Threading.Tasks
Imports System.Web.UI
Imports System.Web.UI.WebControls

Namespace EvaluacionNet
    Partial Public Class Empresas
        Inherits Page

        Private Property CurrentChannel As String
            Get
                Return TryCast(ViewState("Canal"), String)
            End Get
            Set(value As String)
                ViewState("Canal") = value
            End Set
        End Property

        Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
            If Not IsPostBack Then
                RegisterAsyncTask(New PageAsyncTask(AddressOf LoadPageAsync))
            End If
        End Sub

        Private Async Function LoadPageAsync() As Task
            Dim canal = Input.ReadChannel(Request.QueryString("canal"))
            If canal Is Nothing Then
                ShowMessage("El canal indicado no es válido.", True)
                Return
            End If

            CurrentChannel = canal
            Session("CanalActivo") = canal
            lblCanal.Text = "Canal: " & Encode(canal)

            Try
                Dim config = Database.GetChannel(canal)
                If config Is Nothing Then
                    ShowMessage("El canal no existe.", True)
                    Return
                End If

                ConfigureMenu(config, canal)
                Dim empresas = Await ServiceClient.GetEmpresasAsync(config.ServiceUrl, canal, config.ApiKey, config.TimeoutSeconds)
                Session("Empresas_" & canal) = empresas
                rptEmpresas.DataSource = empresas
                rptEmpresas.DataBind()

                If empresas.Count = 0 Then
                    ShowMessage("No hay empresas disponibles para este canal.", False)
                End If
            Catch ex As ApiTimeoutException
                Logger.Error("Empresas.Timeout." & canal, ex)
                ShowMessage("El servicio tardó demasiado. Intenta nuevamente.", True)
            Catch ex As ApiUnauthorizedException
                Logger.Error("Empresas.Unauthorized." & canal, ex)
                ShowMessage("No fue posible validar el acceso al servicio.", True)
            Catch ex As Exception
                Logger.Error("Empresas." & canal, ex)
                ShowMessage("No fue posible cargar las empresas. Intenta nuevamente.", True)
            End Try
        End Function

        Private Sub ConfigureMenu(config As CanalConfiguration, canal As String)
            pnlMenu.Visible = config.ShowMenu
            If config.ShowMenu Then
                lnkMenu.NavigateUrl = DestinationUrl(config, canal)
            End If
        End Sub

        Protected Sub rptEmpresas_ItemCommand(source As Object, e As RepeaterCommandEventArgs)
            If Not String.Equals(e.CommandName, "SelectEmpresa", StringComparison.Ordinal) Then
                Return
            End If

            Dim canal = CurrentChannel
            If String.IsNullOrWhiteSpace(canal) Then
                canal = Input.ReadChannel(Request.QueryString("canal"))
            End If

            If canal Is Nothing Then
                ShowMessage("El canal indicado no es válido.", True)
                Return
            End If

            Dim empresas = TryCast(Session("Empresas_" & canal), List(Of Empresa))
            If empresas Is Nothing Then
                ShowMessage("La sesión expiró. Recarga el listado.", True)
                Return
            End If

            Dim id As Integer
            If Not Integer.TryParse(Convert.ToString(e.CommandArgument), id) Then
                ShowMessage("La empresa indicada no es válida.", True)
                Return
            End If

            Dim seleccionada = empresas.Find(Function(item) item.Id = id)
            If seleccionada Is Nothing Then
                ShowMessage("La empresa indicada ya no está disponible.", True)
                Return
            End If

            Try
                Dim config = Database.GetChannel(canal)
                If config Is Nothing Then
                    ShowMessage("El canal no existe.", True)
                    Return
                End If

                Session("EmpresaSeleccionada") = seleccionada
                Session("CanalEmpresa") = canal
                Response.Redirect(DestinationUrl(config, canal), False)
                Context.ApplicationInstance.CompleteRequest()
            Catch ex As Exception
                Logger.Error("Empresas.Select." & canal, ex)
                ShowMessage("No fue posible abrir la empresa seleccionada.", True)
            End Try
        End Sub

        Private Function DestinationUrl(config As CanalConfiguration, canal As String) As String
            Dim page = If(config.DestinationPage, String.Empty).Trim()
            If Not page.StartsWith("~/", StringComparison.Ordinal) Then
                page = "~/" & page.TrimStart("/"c)
            End If
            Return ResolveUrl(page) & "?canal=" & Server.UrlEncode(canal)
        End Function

        Protected Function Encode(value As Object) As String
            Return Input.Encode(value)
        End Function

        Protected Function SafeImageUrl(value As Object) As String
            Return Input.SafeImageUrl(value)
        End Function

        Private Sub ShowMessage(message As String, isError As Boolean)
            pnlMessage.Visible = True
            pnlMessage.CssClass = If(isError, "message error", "message")
            lblMessage.Text = Encode(message)
        End Sub
    End Class
End Namespace
