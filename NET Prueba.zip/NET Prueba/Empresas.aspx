<%@ Page Language="VB" Async="true" AutoEventWireup="false" CodeBehind="Empresas.aspx.vb" Inherits="EvaluacionNet.Empresas" %>
<!DOCTYPE html>
<html lang="es">
<head runat="server">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Empresas de pago</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f5f7fa; color: #1d2939; }
        .container { max-width: 980px; margin: 40px auto; padding: 0 20px; }
        .top { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .menu { margin: 18px 0; }
        .menu a, .button { display: inline-block; padding: 10px 14px; border-radius: 6px; background: #195ea8; color: white; text-decoration: none; border: 0; cursor: pointer; }
        .message { margin: 20px 0; padding: 14px; border-radius: 6px; background: #fff4d6; color: #6b4e00; }
        .error { background: #fde2e2; color: #9b1c1c; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px; margin-top: 24px; }
        .card { background: white; border: 1px solid #d0d5dd; border-radius: 8px; padding: 18px; box-shadow: 0 2px 6px rgba(0,0,0,.05); }
        .card img { width: 96px; height: 96px; object-fit: contain; display: block; margin-bottom: 12px; }
        .card h2 { font-size: 18px; min-height: 42px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <main class="container">
            <div class="top">
                <div>
                    <h1>Empresas de pago</h1>
                    <asp:Label ID="lblCanal" runat="server" />
                </div>
            </div>
            <asp:Panel ID="pnlMenu" runat="server" CssClass="menu" Visible="false">
                <asp:HyperLink ID="lnkMenu" runat="server" Text="Ir a página destino" />
            </asp:Panel>
            <asp:Panel ID="pnlMessage" runat="server" CssClass="message" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>
            <asp:Repeater ID="rptEmpresas" runat="server" OnItemCommand="rptEmpresas_ItemCommand">
                <HeaderTemplate><section class="grid"></HeaderTemplate>
                <ItemTemplate>
                    <article class="card">
                        <asp:Image ID="imgLogo" runat="server" ImageUrl='<%# SafeImageUrl(Eval("LogoUrl")) %>' AlternateText='<%# Encode(Eval("Nombre")) %>' />
                        <h2><asp:Literal ID="litNombre" runat="server" Text='<%# Encode(Eval("Nombre")) %>' /></h2>
                        <asp:LinkButton ID="btnSelect" runat="server" CssClass="button" CommandName="SelectEmpresa" CommandArgument='<%# Eval("Id") %>' Text="Seleccionar" />
                    </article>
                </ItemTemplate>
                <FooterTemplate></section></FooterTemplate>
            </asp:Repeater>
        </main>
    </form>
</body>
</html>
