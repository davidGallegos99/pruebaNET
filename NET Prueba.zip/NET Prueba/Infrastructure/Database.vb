Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Namespace EvaluacionNet
    Public NotInheritable Class Database
        Private Sub New()
        End Sub

        Public Shared Function GetChannel(channel As String) As CanalConfiguration
            Dim setting = ConfigurationManager.ConnectionStrings("DefaultConnection")
            If setting Is Nothing Then
                Throw New ConfigurationErrorsException("Missing DefaultConnection.")
            End If

            Using connection As New SqlConnection(setting.ConnectionString)
                Using command As New SqlCommand("dbo.usp_CanalConfiguracion_Obtener", connection)
                    command.CommandType = CommandType.StoredProcedure
                    command.Parameters.Add("@Canal", SqlDbType.VarChar, 20).Value = channel
                    connection.Open()
                    Using reader = command.ExecuteReader(CommandBehavior.SingleRow)
                        If Not reader.Read() Then
                            Return Nothing
                        End If

                        Return New CanalConfiguration With {
                            .Channel = Convert.ToString(reader("Canal")),
                            .ServiceUrl = Convert.ToString(reader("UrlServicio")),
                            .ApiKey = Convert.ToString(reader("ApiKey")),
                            .ShowMenu = Convert.ToBoolean(reader("MuestraMenu")),
                            .DestinationPage = Convert.ToString(reader("PaginaDestino")),
                            .TimeoutSeconds = Convert.ToInt32(reader("TimeoutSegundos"))
                        }
                    End Using
                End Using
            End Using
        End Function
    End Class
End Namespace
