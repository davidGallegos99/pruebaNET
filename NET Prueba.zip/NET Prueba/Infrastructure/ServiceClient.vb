Imports System
Imports System.Collections.Generic
Imports System.Net
Imports System.Net.Http
Imports System.Threading
Imports System.Threading.Tasks
Imports System.Web
Imports System.Web.Script.Serialization

Namespace EvaluacionNet
    Public NotInheritable Class ServiceClient
        Private Shared ReadOnly Client As New HttpClient()

        Shared Sub New()
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
        End Sub

        Private Sub New()
        End Sub

        Public Shared Async Function GetEmpresasAsync(serviceUrl As String,
                                                       channel As String,
                                                       apiKey As String,
                                                       timeoutSeconds As Integer) As Task(Of List(Of Empresa))
            If String.IsNullOrWhiteSpace(serviceUrl) Then
                Throw New ApiRequestException("The configured service URL is empty.", Nothing)
            End If

            Dim url = AddChannelParameter(serviceUrl, channel)
            Dim timeout = Math.Max(1, timeoutSeconds)
            Using timeoutSource As New CancellationTokenSource(TimeSpan.FromSeconds(timeout))
                Using request As New HttpRequestMessage(HttpMethod.Get, url)
                    request.Headers.TryAddWithoutValidation("X-Api-Key", apiKey)
                    Try
                        Using response = Await Client.SendAsync(request,
                                                                HttpCompletionOption.ResponseContentRead,
                                                                timeoutSource.Token)
                            Dim body = Await response.Content.ReadAsStringAsync()
                            If response.StatusCode = HttpStatusCode.Unauthorized Then
                                Throw New ApiUnauthorizedException()
                            End If
                            If Not response.IsSuccessStatusCode Then
                                Throw New ApiRequestException("The service returned HTTP " & CInt(response.StatusCode) & ".", Nothing)
                            End If

                            Dim result = New JavaScriptSerializer().Deserialize(Of List(Of Empresa))(body)
                            Return If(result, New List(Of Empresa)())
                        End Using
                    Catch ex As ApiTimeoutException
                        Throw
                    Catch ex As ApiUnauthorizedException
                        Throw
                    Catch ex As ApiRequestException
                        Throw
                    Catch ex As TaskCanceledException
                        If timeoutSource.IsCancellationRequested Then
                            Throw New ApiTimeoutException()
                        End If
                        Throw
                    Catch ex As Exception
                        Throw New ApiRequestException("The service request failed.", ex)
                    End Try
                End Using
            End Using
        End Function

        Private Shared Function AddChannelParameter(serviceUrl As String, channel As String) As String
            Dim separator = "?"
            If serviceUrl.Contains("?") Then
                separator = If(serviceUrl.EndsWith("?", StringComparison.Ordinal) OrElse
                               serviceUrl.EndsWith("&", StringComparison.Ordinal), String.Empty, "&")
            End If
            Return serviceUrl & separator & "canal=" & HttpUtility.UrlEncode(channel)
        End Function
    End Class
End Namespace
