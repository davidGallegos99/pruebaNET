Imports System
Imports System.IO
Imports System.Text
Imports System.Web.Hosting

Namespace EvaluacionNet
    Public NotInheritable Class Logger
        Private Sub New()
        End Sub

        Public Shared Sub [Error](source As String, exception As Exception)
            Try
                Dim folder = HostingEnvironment.MapPath("~/App_Data")
                If String.IsNullOrWhiteSpace(folder) Then
                    Return
                End If

                Directory.CreateDirectory(folder)
                Dim line = String.Format("{0:u} | {1} | {2}{3}{4}{5}",
                                         DateTime.UtcNow,
                                         source,
                                         exception.Message,
                                         Environment.NewLine,
                                         exception.StackTrace,
                                         Environment.NewLine)
                File.AppendAllText(Path.Combine(folder, "application.log"), line, Encoding.UTF8)
            Catch
                ' Logging no debe romper la respuesta al usuario.
            End Try
        End Sub
    End Class
End Namespace
