Imports System

Namespace EvaluacionNet
    Public Class CanalConfiguration
        Public Property Channel As String
        Public Property ServiceUrl As String
        Public Property ApiKey As String
        Public Property ShowMenu As Boolean
        Public Property DestinationPage As String
        Public Property TimeoutSeconds As Integer
    End Class

    Public Class Empresa
        Public Property Id As Integer
        Public Property Nombre As String
        Public Property LogoUrl As String
    End Class

    Public Class ApiTimeoutException
        Inherits Exception

        Public Sub New()
            MyBase.New("The service request exceeded its configured timeout.")
        End Sub
    End Class

    Public Class ApiUnauthorizedException
        Inherits Exception

        Public Sub New()
            MyBase.New("The service rejected the API key.")
        End Sub
    End Class

    Public Class ApiRequestException
        Inherits Exception

        Public Sub New(message As String, innerException As Exception)
            MyBase.New(message, innerException)
        End Sub
    End Class
End Namespace
