Imports System
Imports System.Text.RegularExpressions
Imports System.Web

Namespace EvaluacionNet
    Public NotInheritable Class Input
        Private Sub New()
        End Sub

        Public Shared Function ReadChannel(value As String) As String
            Dim channel = If(value, String.Empty).Trim().ToUpperInvariant()
            If Not Regex.IsMatch(channel, "^[A-Z0-9_-]{1,20}$", RegexOptions.CultureInvariant) Then
                Return Nothing
            End If
            Return channel
        End Function

        Public Shared Function Encode(value As Object) As String
            Return HttpUtility.HtmlEncode(Convert.ToString(value))
        End Function

        Public Shared Function SafeImageUrl(value As Object) As String
            Dim raw = Convert.ToString(value)
            Dim uri As Uri = Nothing
            If Uri.TryCreate(raw, UriKind.Absolute, uri) AndAlso
               (uri.Scheme = Uri.UriSchemeHttp OrElse uri.Scheme = Uri.UriSchemeHttps) Then
                Return raw
            End If
            Return "~/Content/placeholder.svg"
        End Function
    End Class
End Namespace
