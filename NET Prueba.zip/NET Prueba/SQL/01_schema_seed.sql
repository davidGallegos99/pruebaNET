IF DB_ID(N'EvaluacionNet') IS NULL
BEGIN
    CREATE DATABASE [EvaluacionNet];
END
GO

USE [EvaluacionNet];
GO

IF OBJECT_ID(N'dbo.CanalConfiguracion', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CanalConfiguracion
    (
        Canal varchar(20) NOT NULL CONSTRAINT PK_CanalConfiguracion PRIMARY KEY,
        UrlServicio nvarchar(500) NOT NULL,
        ApiKey nvarchar(200) NOT NULL,
        MuestraMenu bit NOT NULL CONSTRAINT DF_CanalConfiguracion_MuestraMenu DEFAULT (0),
        PaginaDestino nvarchar(200) NOT NULL,
        TimeoutSegundos int NOT NULL CONSTRAINT DF_CanalConfiguracion_Timeout DEFAULT (5),
        CONSTRAINT CK_CanalConfiguracion_Timeout CHECK (TimeoutSegundos BETWEEN 1 AND 120)
    );
END
GO

CREATE OR ALTER PROCEDURE dbo.usp_CanalConfiguracion_Obtener
    @Canal varchar(20)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Canal, UrlServicio, ApiKey, MuestraMenu, PaginaDestino, TimeoutSegundos
    FROM dbo.CanalConfiguracion
    WHERE Canal = @Canal;
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.CanalConfiguracion WHERE Canal = 'AB')
BEGIN
    INSERT dbo.CanalConfiguracion (Canal, UrlServicio, ApiKey, MuestraMenu, PaginaDestino, TimeoutSegundos)
    VALUES ('AB', N'http://127.0.0.1:5050/empresas', N'demo-ab-key', 1, N'~/Destino.aspx', 5);
END

IF NOT EXISTS (SELECT 1 FROM dbo.CanalConfiguracion WHERE Canal = 'CJ')
BEGIN
    INSERT dbo.CanalConfiguracion (Canal, UrlServicio, ApiKey, MuestraMenu, PaginaDestino, TimeoutSegundos)
    VALUES ('CJ', N'http://127.0.0.1:5050/empresas', N'demo-cj-key', 0, N'~/Destino.aspx', 2);
END
GO
