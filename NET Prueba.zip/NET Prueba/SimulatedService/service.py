#!/usr/bin/env python3
"""Servicio HTTP simulado para la evaluación.

GET /empresas?canal=AB
Header: X-Api-Key: demo-ab-key

Pruebas:
  ?delay=3  -> demora artificial
  ?error=1  -> HTTP 500
"""

import json
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PORT", "5050"))
CHANNELS = {
    "AB": {
        "key": "demo-ab-key",
        "companies": [
            {"id": 1, "nombre": "Agua Azul", "logoUrl": "https://placehold.co/96x96/png?text=AA"},
            {"id": 2, "nombre": "Energía Norte", "logoUrl": "https://placehold.co/96x96/png?text=EN"},
        ],
    },
    "CJ": {
        "key": "demo-cj-key",
        "companies": [
            {"id": 3, "nombre": "Cable Jardín", "logoUrl": "https://placehold.co/96x96/png?text=CJ"},
            {"id": 4, "nombre": "Gas Central", "logoUrl": "https://placehold.co/96x96/png?text=GC"},
        ],
    },
}


class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != "/empresas":
            self.send_json(404, {"error": "ruta no encontrada"})
            return

        query = parse_qs(parsed.query)
        channel = query.get("canal", [""])[0].upper()
        config = CHANNELS.get(channel)
        if config is None:
            self.send_json(404, {"error": "canal no encontrado"})
            return
        if self.headers.get("X-Api-Key") != config["key"]:
            self.send_json(401, {"error": "api key inválida"})
            return

        delay = min(max(float(query.get("delay", ["0"])[0]), 0), 30)
        if delay:
            time.sleep(delay)
        if query.get("error", [""])[0] in {"1", "true", "500"}:
            self.send_json(500, {"error": "error simulado"})
            return

        self.send_json(200, config["companies"])

    def log_message(self, format_string, *args):
        print("%s - %s" % (self.address_string(), format_string % args))


if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print("Servicio simulado escuchando en http://127.0.0.1:%d" % PORT)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
