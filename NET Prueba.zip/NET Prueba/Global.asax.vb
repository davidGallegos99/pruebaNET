Imports System

Namespace EvaluacionNet
    Public Class Global_asax
        Inherits System.Web.HttpApplication

        Protected Sub Application_Error(sender As Object, e As EventArgs)
            Try
                Dim exception = Server.GetLastError()
                Logger.Error("Application", exception)
                Server.ClearError()
                Response.Redirect("~/Error.aspx", False)
                Context.ApplicationInstance.CompleteRequest()
            Catch
                ' No volver a lanzar un error desde el manejador global.
            End Try
        End Sub
    End Class
End Namespace
