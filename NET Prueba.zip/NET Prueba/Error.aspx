<%@ Page Language="VB" AutoEventWireup="false" %>
<!DOCTYPE html>
<html lang="es">
<head runat="server">
    <meta charset="utf-8" />
    <title>Error</title>
</head>
<body>
    <form id="form1" runat="server">
        <main style="font-family:Arial,sans-serif;max-width:680px;margin:60px auto">
            <h1>No fue posible completar la solicitud</h1>
            <p>Ocurrió un error controlado. Intenta nuevamente.</p>
        </main>
    </form>
</body>
</html>
