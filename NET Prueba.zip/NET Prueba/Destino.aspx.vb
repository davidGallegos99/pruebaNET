Imports System
Imports System.Web.UI

Namespace EvaluacionNet
    Partial Public Class Destino
        Inherits Page

        Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
            If IsPostBack Then
                Return
            End If

            Dim canal = Input.ReadChannel(Request.QueryString("canal"))
            Dim empresa = TryCast(Session("EmpresaSeleccionada"), Empresa)
            Dim canalEmpresa = Input.ReadChannel(Convert.ToString(Session("CanalEmpresa")))

            If empresa Is Nothing OrElse canal Is Nothing OrElse Not String.Equals(canal, canalEmpresa, StringComparison.Ordinal) Then
                RedirectToList(canal)
                Return
            End If

            lblCanal.Text = "Canal: " & Input.Encode(canal)
            litNombre.Text = Input.Encode(empresa.Nombre)
            imgLogo.ImageUrl = Input.SafeImageUrl(empresa.LogoUrl)
            imgLogo.AlternateText = Input.Encode(empresa.Nombre)
            lnkListado.NavigateUrl = ResolveUrl("~/Empresas.aspx?canal=" & Server.UrlEncode(canal))
        End Sub

        Private Sub RedirectToList(canal As String)
            Dim url = ResolveUrl("~/Empresas.aspx")
            If canal IsNot Nothing Then
                url &= "?canal=" & Server.UrlEncode(canal)
            End If
            Response.Redirect(url, False)
            Context.ApplicationInstance.CompleteRequest()
        End Sub
    End Class
End Namespace
