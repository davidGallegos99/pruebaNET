# Evaluación técnica .NET

Implementación del apartado B: sitio ASP.NET Web Forms en VB.NET (.NET Framework 4.8), configuración por canal en SQL Server y servicio HTTP simulado.

## Requisitos

- Windows + Visual Studio 2022 con workload **ASP.NET and web development**.
- .NET Framework 4.8 Developer Pack.
- SQL Server Express o LocalDB.
- Python 3 para el servicio simulado.

## 1. Base de datos

Abrir `SQL/01_schema_seed.sql` en SQL Server Management Studio o Azure Data Studio y ejecutarlo. Crea la base `EvaluacionNet`, la tabla de configuración, el procedimiento almacenado y los canales `AB` y `CJ`.

La aplicación usa por defecto:

```text
Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=EvaluacionNet;Integrated Security=True
```

Para SQL Express, cambiar `Data Source` en `Web.config` a `.\SQLEXPRESS`.

## 2. Servicio simulado

Desde la raíz del repositorio:

```bash
python SimulatedService/service.py
```

Endpoint normal:

```bash
curl -H "X-Api-Key: demo-ab-key" "http://127.0.0.1:5050/empresas?canal=AB"
```

Casos de prueba:

```bash
# API key inválida -> 401
curl -i -H "X-Api-Key: incorrecta" "http://127.0.0.1:5050/empresas?canal=AB"

# Error del servicio -> 500
curl -i -H "X-Api-Key: demo-ab-key" "http://127.0.0.1:5050/empresas?canal=AB&error=1"

# Demora artificial de 6 segundos
curl -i -H "X-Api-Key: demo-ab-key" "http://127.0.0.1:5050/empresas?canal=AB&delay=6"
```

## 3. Ejecutar sitio

1. Abrir `EvaluacionNet.sln` en Visual Studio.
2. Confirmar que el servicio simulado está ejecutándose.
3. Ejecutar el proyecto con IIS Express.
4. Abrir:
   - `Empresas.aspx?canal=AB`: menú visible, timeout de 5 segundos.
   - `Empresas.aspx?canal=CJ`: menú oculto, timeout de 2 segundos.
5. Seleccionar empresa: guarda la selección en sesión y redirige a `Destino.aspx`.

Los errores muestran mensajes controlados y escriben el detalle técnico en `App_Data/application.log`. La API key nunca se muestra al usuario.

## 4. Agregar canal sin modificar código

Agregar una fila a `dbo.CanalConfiguracion`, por ejemplo:

```sql
INSERT dbo.CanalConfiguracion
    (Canal, UrlServicio, ApiKey, MuestraMenu, PaginaDestino, TimeoutSegundos)
VALUES
    ('DX', N'http://127.0.0.1:5050/empresas', N'demo-dx-key', 1, N'~/Destino.aspx', 5);
```

El sitio usa el mismo flujo y la misma página para cualquier canal válido. El nuevo canal debe existir también en el servicio real o simulado para devolver sus empresas.

Para probar timeout/error desde la configuración, se puede cambiar temporalmente `UrlServicio` a `http://127.0.0.1:5050/empresas?delay=6` o `http://127.0.0.1:5050/empresas?error=1`; el cliente conserva esos parámetros y agrega `canal`.

## Estructura

- `Empresas.aspx`: listado, menú configurable y selección.
- `Destino.aspx`: empresa en sesión; si sesión expira, vuelve al listado.
- `Infrastructure/Database.vb`: ADO.NET, parámetros, `Using`, procedimiento almacenado.
- `Infrastructure/ServiceClient.vb`: `HttpClient` reutilizado, TLS 1.2, timeout y errores HTTP.
- `SQL/01_schema_seed.sql`: esquema, procedimiento y datos iniciales.
- `SimulatedService/service.py`: servicio 200/401/404/500 con demora configurable.
